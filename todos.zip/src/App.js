import logo from "./logo.svg";
import "./App.css";

import NewTodo from "./components/NewTodo";



function App() {
  return (
    <>
      <NewTodo />
    </>
  );
}
export default App;
