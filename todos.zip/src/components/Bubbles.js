import React from 'react'
import '../bubbles.css'
/* import bubble from '../styles/Bubbles.module.css' */

export default function Bubbles() {
    return (
        <>
            <div class="container bublecon">
                <div class="bubble">
                    <span style={{ "--i": "11" }}></span>
                    <span style={{ "--i": "23" }}></span>
                    <span style={{ "--i": "12" }}></span>
                    <span style={{ "--i": "13" }}></span>
                    <span style={{ "--i": "14" }}></span>
                    <span style={{ "--i": "15" }}></span>
                    <span style={{ "--i": "21" }}></span>
                    <span style={{ "--i": "22" }}></span>
                    <span style={{ "--i": "23" }}></span>
                    <span style={{ "--i": "24" }}></span>
                    <span style={{ "--i": "27" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "25" }}></span>
                    <span style={{ "--i": "28" }}></span>
                    <span style={{ "--i": "29" }}></span>
                    <span style={{ "--i": "30" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "18" }}></span>
                    <span style={{ "--i": "12" }}></span>
                    <span style={{ "--i": "11" }}></span>
                    <span style={{ "--i": "11" }}></span>
                    <span style={{ "--i": "23" }}></span>
                    <span style={{ "--i": "12" }}></span>
                    <span style={{ "--i": "13" }}></span>
                    <span style={{ "--i": "14" }}></span>
                    <span style={{ "--i": "15" }}></span>
                    <span style={{ "--i": "21" }}></span>
                    <span style={{ "--i": "22" }}></span>
                    <span style={{ "--i": "23" }}></span>
                    <span style={{ "--i": "24" }}></span>
                    <span style={{ "--i": "27" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "25" }}></span>
                    <span style={{ "--i": "28" }}></span>
                    <span style={{ "--i": "29" }}></span>
                    <span style={{ "--i": "30" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "18" }}></span>
                    <span style={{ "--i": "12" }}></span>
                    <span style={{ "--i": "11" }}></span>
                    <span style={{ "--i": "22" }}></span>
                    <span style={{ "--i": "23" }}></span>
                    <span style={{ "--i": "24" }}></span>
                    <span style={{ "--i": "27" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "25" }}></span>
                    <span style={{ "--i": "28" }}></span>
                    <span style={{ "--i": "29" }}></span>
                    <span style={{ "--i": "30" }}></span>
                    <span style={{ "--i": "26" }}></span>
                    <span style={{ "--i": "18" }}></span>
                    <span style={{ "--i": "12" }}></span>
                    <span style={{ "--i": "11" }}></span>
                    <span style={{ "--i": "22" }}></span>


                </div>
            </div>
        </>
    )
}
